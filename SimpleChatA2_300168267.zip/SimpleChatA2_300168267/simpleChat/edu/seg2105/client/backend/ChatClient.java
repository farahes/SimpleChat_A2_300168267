// This file contains material supporting section 3.7 of the textbook:

package edu.seg2105.client.backend;

import ocsf.client.*;

import java.io.*;

import edu.seg2105.client.common.*;

/**
 * This class overrides some of the methods defined in the abstract
 * superclass in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 */
public class ChatClient extends AbstractClient
{
  //Instance variables **********************************************
  
  /**
   * The interface type variable.  It allows the implementation of 
   * the display method in the client.
   */
  ChatIF clientUI; 

  /**
   * The login ID of the client (used in later exercises).
   */
  private String loginId;

  
  //Constructors ****************************************************

  /**
   * Constructs an instance of the chat client.
   *
   * @param host The server to connect to.
   * @param port The port number to connect on.
   * @param clientUI The interface type variable.
   */
  public ChatClient(String host, int port, ChatIF clientUI) 
    throws IOException 
  {
    super(host, port); //Call the superclass constructor
    this.clientUI = clientUI;
    openConnection();
  }

  /**
   * Overloaded constructor that includes loginId (for Exercise 3).
   *
   * @param loginId The login ID of the client.
   * @param host The server to connect to.
   * @param port The port number to connect on.
   * @param clientUI The interface type variable.
   */
  public ChatClient(String loginId, String host, int port, ChatIF clientUI) 
    throws IOException 
  {
    super(host, port);
    this.clientUI = clientUI;
    this.loginId = loginId;
    openConnection();
  }

  
  //Instance methods ************************************************
    
  /**
   * This method handles all data that comes in from the server.
   *
   * @param msg The message from the server.
   */
  public void handleMessageFromServer(Object msg) 
  {
    clientUI.display(msg.toString());
  }

  /**
   * This method handles all data coming from the UI            
   *
   * @param message The message from the UI.    
   */
  public void handleMessageFromClientUI(String message)
  {
    try
    {
      sendToServer(message);
    }
    catch(IOException e)
    {
      clientUI.display
        ("Could not send message to server.  Terminating client.");
      quit();
    }
  }
  
  /**
   * This method terminates the client.
   */
  public void quit()
  {
    try
    {
      closeConnection();
    }
    catch(IOException e) {}
    System.exit(0);
  }

  /**
   * This method is triggered when the connection to the server is closed.
   * It handles clean shutdown when the server stops.
   */
  @Override
  protected void connectionClosed() {
    clientUI.display("Connection closed. Server has shut down.");
    System.exit(0);
  }

  /**
   * This method is triggered when an exception occurs during communication.
   * It handles unexpected server disconnections.
   *
   * @param exception The exception that occurred.
   */
  @Override
  protected void connectionException(Exception exception) {
    clientUI.display("Server disconnected unexpectedly.");
    System.exit(0);
  }

  /**
   * This method is triggered when the connection is successfully established.
   * Sends the login ID to the server immediately after connection.
   */
  @Override
  protected void connectionEstablished() {
    try {
      sendToServer("#login " + loginId);
    } catch (IOException e) {
      clientUI.display("ERROR: Could not send login ID to server.");
      quit();
    }
  }

  /**
   * Getter for loginId (used in Exercise 3).
   *
   * @return The login ID string.
   */
  public String getLoginId() {
    return loginId;
  }
}
//End of ChatClient class


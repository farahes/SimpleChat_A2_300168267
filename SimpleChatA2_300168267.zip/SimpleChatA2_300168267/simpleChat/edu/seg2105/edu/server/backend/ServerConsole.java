package edu.seg2105.edu.server.backend;

import edu.seg2105.client.common.ChatIF;
import java.io.IOException;
import java.util.Scanner;

/**
 * This class provides a console interface to control the EchoServer.
 */
public class ServerConsole implements ChatIF {

  final public static int DEFAULT_PORT = 5555;
  EchoServer server;
  Scanner fromConsole;

  /**
   * Constructs a ServerConsole with the specified port.
   */
  public ServerConsole(int port) {
    try {
      server = new EchoServer(port);
      server.listen();  // Start listening for client connections
    } catch (Exception ex) {
      System.out.println("ERROR - Could not listen for clients!");
      System.exit(1);
    }
    fromConsole = new Scanner(System.in);
  }

  /**
   * This method waits for input from the console and processes commands.
   */
  public void accept() {
    try {
      String message;

      while (true) {
        message = fromConsole.nextLine();

        if (message.startsWith("#")) {
          handleCommand(message);
        } else {
          // Echo input to all clients with prefix
          server.sendToAllClients("SERVER MSG> " + message);
          System.out.println("SERVER MSG> " + message);
        }
      }
    } catch (Exception ex) {
      System.out.println("Unexpected error while reading from console!");
    }
  }

  /**
   * Parses and executes server-side commands.
   */
  public void handleCommand(String command) {
    if (command.equals("#quit")) {
      try {
        server.close();
      } catch (IOException e) {}
      System.exit(0);
    } else if (command.equals("#stop")) {
      server.stopListening();
    } else if (command.equals("#close")) {
      try {
        server.close();  // Stops and disconnects all clients
      } catch (IOException e) {
        System.out.println("Failed to close server.");
      }
    } else if (command.startsWith("#setport")) {
      if (!server.isListening()) {
        String[] parts = command.split(" ");
        if (parts.length == 2) {
          try {
            int newPort = Integer.parseInt(parts[1]);
            server.setPort(newPort);
            System.out.println("Port set to " + newPort);
          } catch (NumberFormatException e) {
            System.out.println("Invalid port number.");
          }
        } else {
          System.out.println("Usage: #setport <port>");
        }
      } else {
        System.out.println("Cannot set port while server is listening.");
      }
    } else if (command.equals("#start")) {
      if (!server.isListening()) {
        try {
          server.listen();
          System.out.println("Server started.");
        } catch (IOException e) {
          System.out.println("Could not start server.");
        }
      } else {
        System.out.println("Server is already running.");
      }
    } else if (command.equals("#getport")) {
      System.out.println("Current server port: " + server.getPort());
    } else {
      System.out.println("Unknown command: " + command);
    }
  }

  /**
   * Implements the ChatIF display method (prints messages to the console).
   */
  public void display(String message) {
    System.out.println("> " + message);
  }

  /**
   * Entry point for the server console.
   */
  public static void main(String[] args) {
    int port = DEFAULT_PORT;

    try {
      port = Integer.parseInt(args[0]);
    } catch (ArrayIndexOutOfBoundsException e) {
      port = DEFAULT_PORT; // use default
    }

    ServerConsole sc = new ServerConsole(port);
    sc.accept();  // Start reading input
  }
}

